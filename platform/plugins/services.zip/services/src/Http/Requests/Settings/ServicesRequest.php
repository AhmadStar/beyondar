<?php

namespace Botble\Services\Http\Requests\Settings;

use Botble\Support\Http\Requests\Request;

class ServicesRequest extends Request
{
    public function rules(): array
    {
        return [];
    }
}
