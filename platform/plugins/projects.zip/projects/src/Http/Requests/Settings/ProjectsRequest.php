<?php

namespace Botble\Projects\Http\Requests\Settings;

use Botble\Support\Http\Requests\Request;

class ProjectsRequest extends Request
{
    public function rules(): array
    {
        return [];
    }
}
