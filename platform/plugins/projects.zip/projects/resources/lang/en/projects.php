<?php

return [
    'name' => 'Projects',
    'create' => 'New projects',
];
