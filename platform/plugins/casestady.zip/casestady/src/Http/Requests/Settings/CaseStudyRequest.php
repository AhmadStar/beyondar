<?php

namespace Botble\CaseStady\Http\Requests\Settings;

use Botble\Support\Http\Requests\Request;

class CaseStudyRequest extends Request
{
    public function rules(): array
    {
        return [];
    }
}
