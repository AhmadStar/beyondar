<?php

use Illuminate\Support\Facades\Route;
use Botble\Base\Facades\AdminHelper;

Route::group(['namespace' => 'Botble\CaseStudy\Http\Controllers'], function () {
    AdminHelper::registerRoutes(function () {
        Route::group(['prefix' => 'case-studies', 'as' => 'case-study.'], function () {
            Route::resource('', 'CaseStudyController')->parameters(['' => 'case-study']);
        });
    });
});
