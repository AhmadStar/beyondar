<?php

namespace Botble\CaseStudy\Http\Controllers;

use Botble\Base\Http\Actions\DeleteResourceAction;
use Botble\CaseStudy\Http\Requests\CaseStudyRequest;
use Botble\CaseStudy\Models\CaseStudy;
use Botble\Base\Facades\PageTitle;
use Botble\Base\Http\Controllers\BaseController;
use Botble\CaseStudy\Tables\CaseStudyTable;
use Botble\CaseStudy\Forms\CaseStudyForm;

class CaseStudyController extends BaseController
{
    public function __construct()
    {
        $this
            ->breadcrumb()
            ->add(trans(trans('plugins/case study::case-study.name')), route('case-study.index'));
    }

    public function index(CaseStudyTable $table)
    {
        $this->pageTitle(trans('plugins/case study::case-study.name'));

        return $table->renderTable();
    }

    public function create()
    {
        $this->pageTitle(trans('plugins/case study::case-study.create'));

        return CaseStudyForm::create()->renderForm();
    }

    public function store(CaseStudyRequest $request)
    {
        $form = CaseStudyForm::create()->setRequest($request);

        $form->save();

        return $this
            ->httpResponse()
            ->setPreviousUrl(route('case-study.index'))
            ->setNextUrl(route('case-study.edit', $form->getModel()->getKey()))
            ->setMessage(trans('core/base::notices.create_success_message'));
    }

    public function edit(CaseStudy $caseStudy)
    {
        $this->pageTitle(trans('core/base::forms.edit_item', ['name' => $caseStudy->name]));

        return CaseStudyForm::createFromModel($caseStudy)->renderForm();
    }

    public function update(CaseStudy $caseStudy, CaseStudyRequest $request)
    {
        CaseStudyForm::createFromModel($caseStudy)
            ->setRequest($request)
            ->save();

        return $this
            ->httpResponse()
            ->setPreviousUrl(route('case-study.index'))
            ->setMessage(trans('core/base::notices.update_success_message'));
    }

    public function destroy(CaseStudy $caseStudy)
    {
        return DeleteResourceAction::make($caseStudy);
    }
}
