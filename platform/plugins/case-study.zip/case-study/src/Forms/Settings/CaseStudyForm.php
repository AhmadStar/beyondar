<?php

namespace Botble\CaseStudy\Forms\Settings;

use Botble\CaseStudy\Http\Requests\Settings\CaseStudyRequest;
use Botble\Setting\Forms\SettingForm;

class CaseStudyForm extends SettingForm
{
    public function buildForm(): void
    {
        parent::buildForm();

        $this
            ->setSectionTitle('Setting title')
            ->setSectionDescription('Setting description')
            ->setValidatorClass(CaseStudyRequest::class);
    }
}
