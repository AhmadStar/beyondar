<?php

namespace Botble\CaseStudy;

use Illuminate\Support\Facades\Schema;
use Botble\PluginManagement\Abstracts\PluginOperationAbstract;

class Plugin extends PluginOperationAbstract
{
    public static function remove(): void
    {
        Schema::dropIfExists('Case Studies');
        Schema::dropIfExists('Case Studies_translations');
    }
}
