<?php

return [
    [
        'name' => 'Case studies',
        'flag' => 'case-study.index',
    ],
    [
        'name' => 'Create',
        'flag' => 'case-study.create',
        'parent_flag' => 'case-study.index',
    ],
    [
        'name' => 'Edit',
        'flag' => 'case-study.edit',
        'parent_flag' => 'case-study.index',
    ],
    [
        'name' => 'Delete',
        'flag' => 'case-study.destroy',
        'parent_flag' => 'case-study.index',
    ],
];
