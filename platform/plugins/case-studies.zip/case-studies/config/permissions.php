<?php

return [
    [
        'name' => 'Case studies',
        'flag' => 'case-studies.index',
    ],
    [
        'name' => 'Create',
        'flag' => 'case-studies.create',
        'parent_flag' => 'case-studies.index',
    ],
    [
        'name' => 'Edit',
        'flag' => 'case-studies.edit',
        'parent_flag' => 'case-studies.index',
    ],
    [
        'name' => 'Delete',
        'flag' => 'case-studies.destroy',
        'parent_flag' => 'case-studies.index',
    ],
];
