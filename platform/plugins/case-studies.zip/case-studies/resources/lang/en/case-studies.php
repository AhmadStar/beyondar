<?php

return [
    'name' => 'Case studies',
    'create' => 'New case studies',
];
