<?php

use Illuminate\Support\Facades\Route;
use Botble\Base\Facades\AdminHelper;

Route::group(['namespace' => 'Botble\CaseStudies\Http\Controllers'], function () {
    AdminHelper::registerRoutes(function () {
        Route::group(['prefix' => 'case-studies', 'as' => 'case-studies.'], function () {
            Route::resource('', 'CaseStudiesController')->parameters(['' => 'case-studies']);
        });
    });
});
