<?php

namespace Botble\CaseStudies\Http\Requests\Settings;

use Botble\Support\Http\Requests\Request;

class CaseStudiesRequest extends Request
{
    public function rules(): array
    {
        return [];
    }
}
