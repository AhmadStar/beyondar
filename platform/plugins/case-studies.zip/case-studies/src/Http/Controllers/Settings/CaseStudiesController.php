<?php

namespace Botble\CaseStudies\Http\Controllers\Settings;

use Botble\Base\Forms\FormBuilder;
use Botble\CaseStudies\Forms\Settings\CaseStudiesForm;
use Botble\CaseStudies\Http\Requests\Settings\CaseStudiesRequest;
use Botble\Setting\Http\Controllers\SettingController;

class CaseStudiesController extends SettingController
{
    public function edit(FormBuilder $formBuilder)
    {
        $this->pageTitle('Page title');

        return $formBuilder->create(CaseStudiesForm::class)->renderForm();
    }

    public function update(CaseStudiesRequest $request)
    {
        return $this->performUpdate($request->validated());
    }
}
