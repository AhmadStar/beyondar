<?php

namespace Botble\CaseStudies\Http\Controllers;

use Botble\Base\Http\Actions\DeleteResourceAction;
use Botble\CaseStudies\Http\Requests\CaseStudiesRequest;
use Botble\CaseStudies\Models\CaseStudies;
use Botble\Base\Facades\PageTitle;
use Botble\Base\Http\Controllers\BaseController;
use Botble\CaseStudies\Tables\CaseStudiesTable;
use Botble\CaseStudies\Forms\CaseStudiesForm;

class CaseStudiesController extends BaseController
{
    public function __construct()
    {
        $this
            ->breadcrumb()
            ->add(trans(trans('plugins/case studies::case-studies.name')), route('case-studies.index'));
    }

    public function index(CaseStudiesTable $table)
    {
        $this->pageTitle(trans('plugins/case studies::case-studies.name'));

        return $table->renderTable();
    }

    public function create()
    {
        $this->pageTitle(trans('plugins/case studies::case-studies.create'));

        return CaseStudiesForm::create()->renderForm();
    }

    public function store(CaseStudiesRequest $request)
    {
        $form = CaseStudiesForm::create()->setRequest($request);

        $form->save();

        return $this
            ->httpResponse()
            ->setPreviousUrl(route('case-studies.index'))
            ->setNextUrl(route('case-studies.edit', $form->getModel()->getKey()))
            ->setMessage(trans('core/base::notices.create_success_message'));
    }

    public function edit(CaseStudies $caseStudies)
    {
        $this->pageTitle(trans('core/base::forms.edit_item', ['name' => $caseStudies->name]));

        return CaseStudiesForm::createFromModel($caseStudies)->renderForm();
    }

    public function update(CaseStudies $caseStudies, CaseStudiesRequest $request)
    {
        CaseStudiesForm::createFromModel($caseStudies)
            ->setRequest($request)
            ->save();

        return $this
            ->httpResponse()
            ->setPreviousUrl(route('case-studies.index'))
            ->setMessage(trans('core/base::notices.update_success_message'));
    }

    public function destroy(CaseStudies $caseStudies)
    {
        return DeleteResourceAction::make($caseStudies);
    }
}
