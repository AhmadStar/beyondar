<?php

namespace Botble\CaseStudies\PanelSections;

use Botble\Base\PanelSections\PanelSection;

class CaseStudiesPanelSection extends PanelSection
{
    public function setup(): void
    {
        $this
            ->setId('settings.{id}')
            ->setTitle('{title}')
            ->withItems([
                //
            ]);
    }
}
