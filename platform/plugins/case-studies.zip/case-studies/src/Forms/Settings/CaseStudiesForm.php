<?php

namespace Botble\CaseStudies\Forms\Settings;

use Botble\CaseStudies\Http\Requests\Settings\CaseStudiesRequest;
use Botble\Setting\Forms\SettingForm;

class CaseStudiesForm extends SettingForm
{
    public function buildForm(): void
    {
        parent::buildForm();

        $this
            ->setSectionTitle('Setting title')
            ->setSectionDescription('Setting description')
            ->setValidatorClass(CaseStudiesRequest::class);
    }
}
