<?php

namespace Botble\CaseStudies\Providers;

use Botble\Base\Supports\ServiceProvider;
use Botble\Base\Traits\LoadAndPublishDataTrait;
use Botble\Base\Facades\DashboardMenu;
use Botble\CaseStudies\Models\CaseStudies;

class CaseStudiesServiceProvider extends ServiceProvider
{
    use LoadAndPublishDataTrait;

    public function boot(): void
    {
        $this
            ->setNamespace('plugins/case-studies')
            ->loadHelpers()
            ->loadAndPublishConfigurations(["permissions"])
            ->loadAndPublishTranslations()
            ->loadRoutes()
            ->loadAndPublishViews()
            ->loadMigrations();
            
            if (defined('LANGUAGE_ADVANCED_MODULE_SCREEN_NAME')) {
                \Botble\LanguageAdvanced\Supports\LanguageAdvancedManager::registerModule(CaseStudies::class, [
                    'name',
                ]);
            }
            
            DashboardMenu::default()->beforeRetrieving(function () {
                DashboardMenu::registerItem([
                    'id' => 'cms-plugins-case studies',
                    'priority' => 5,
                    'parent_id' => null,
                    'name' => 'plugins/case studies::case studies.name',
                    'icon' => 'fa fa-list',
                    'url' => route('case studies.index'),
                    'permissions' => ['case studies.index'],
                ]);
            });
    }
}
